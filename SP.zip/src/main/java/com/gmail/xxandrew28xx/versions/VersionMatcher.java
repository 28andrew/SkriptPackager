package com.gmail.xxandrew28xx.versions;

public interface VersionMatcher {
	boolean matches(String version);
}
